const tasks = [
    {
        id: 1,
        text: 'test 1'
    },
    {
        id: 2,
        text: 'test 1'
    },
    {
        id: 3,
        text: 'test 1'
    }

]

const Tasks = () => {
    return (
        <div>
            
        </div>
    )
}

export default Tasks
