const Button = () => {
    return (
        <button className='btn'>Add</button>
    )
}

export default Button
