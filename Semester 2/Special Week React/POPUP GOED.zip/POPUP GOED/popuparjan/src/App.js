import Popup from './Popup'
import {useState} from 'react'
import './image.css'

function App() {
  const [buttonPopup, setButtonPopup] = useState(false);
  return (
    <div>
      <main><button onClick={() => setButtonPopup(true)}>Open Popup</button></main>

      <Popup trigger={buttonPopup} setTrigger={setButtonPopup}>
        <h3>Mijn Popup</h3>
        <p>Hallo allemaal</p>
        <img className='image' src='https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Macaca_nigra_self-portrait_large.jpg/800px-Macaca_nigra_self-portrait_large.jpg'></img>
      </Popup>
    </div>
  );
}

export default App;
